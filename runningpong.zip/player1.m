function [] = player1()

global quitGame;

quitGame = false;

[mainAxis, PAD1, pongPlot, PAD_W, PAD_H, axisTitle] = initialize_graphics();

titlestring = "Type q to Quit";

print_title(axisTitle, titlestring);



while quitGame == false

    k = get(gcf,'CurrentCharacter');

    if k == 'q'
   
        quitGame = true;

    else
        
        [mousePos] = get_mouse_position(mainAxis);
        
        %write player1's current mouse position
        fid = fopen('player1data' , 'w');
        fprintf(fid,'%f ' , mousePos);
        fclose(fid);

        pause(0.025)

        %read player2's position
        fid = fopen('player2data', 'r');
        pad2pos = fscanf(fid,'%f',[1,2]);
        fclose(fid);

        draw_object(mainAxis, PAD1, pongPlot, PAD_W, PAD_H, mousePos);
        
    end

end

end