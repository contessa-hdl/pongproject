function KeyPressFcnTest
    close all;
    h = figure;
    set(h, 'WindowKeyFcn' , @KeyPressFcn);
    function KeyPressFcn(~,event)
        fprintft('key event is: %s\n', event.Key);
    end
end